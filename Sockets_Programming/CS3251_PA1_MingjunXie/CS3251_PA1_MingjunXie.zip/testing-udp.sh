python sensor-udp.py -s 172.17.0.3 -p 8591 -u mxie33 -c 960902 -r 10
python sensor-udp.py -s 172.17.0.3 -p 8591 -u mxie3 -c 960902 -r 10
python sensor-udp.py -s 172.17.0.3 -p 8591 -u mxie33 -c 960903 -r 10
python sensor-udp.py -s 172.17.0.3 -p 8591 -u xyuan39 -c 940715 -r 20
python sensor-udp.py -s 172.17.0.3 -p 8591 -u tgong7 -c 950119 -r 30
python sensor-udp.py -s 172.17.0.3 -p 8591 -u yzhou376 -c 960318 -r 40
python sensor-udp.py -s 172.17.0.3 -p 8591 -u zwu78 -c 940715 -r 50
python sensor-udp.py -s 172.17.0.3 -p 8591 -u zwu78 -c 940715 -r aaa
